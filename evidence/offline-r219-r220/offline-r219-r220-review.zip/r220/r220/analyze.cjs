const fs=require('fs'),vm=require('vm'),assert=require('assert');process.chdir(__dirname);
const c={window:{r111Enabled:true},performance:{now:()=>0},console};vm.createContext(c);
for(const f of ['r111/orbit.js','r116/handoff.js','r186/state.js','r186/choose.js'])vm.runInContext(fs.readFileSync('../'+f,'utf8'),c);
const h=fs.readFileSync('../r218/A.html','utf8');vm.runInContext(h.slice(h.indexOf('const dirs='),h.indexOf('let lastVision=')),c);
const groups=[['development','r218',675,690],['wall-top','r218',181,183],['wall-right','r218',425,427],['success1','r209',229,232],['success2','r161',143,145],['wall-tradeoff','r209',324,352]];let out=[];
for(const [group,stage,lo,hi] of groups){const raw=JSON.parse(fs.readFileSync('../'+stage+'/A-results-noimages.json'));const rows=raw.rows;
for(let i=2;i<rows.length;i++){const r=rows[i];if(r.r65Seq<lo||r.r65Seq>hi)continue;const prev=rows.slice(i-2,i+1),p=r.planInput;
const signal=prev.every(v=>v.hud===r.hud&&v.clearance>0)&&prev[0].clearance>prev[1].clearance&&prev[1].clearance>r.clearance&&r.clearance<r.hud&&r.ms-prev[0].ms<=1000;
const d=c.wallPlan136([...p.objects,...(r.telemetry.core?.objects||[])],p.hud,p.map,p.speed,p.velocity,p.heading,p.splitGuard);
const same=d.choices.find(q=>q.name===r.planOutput.name);const candidates=same?d.choices.filter(q=>q.name!==same.name&&q.clearance>same.clearance&&q.risk<=same.risk&&q.minWall>=same.minWall):[];
out.push({group,stage,seq:r.r65Seq,signal,ms:r.ms,detectedWalls:p.map?.visibleWalls||null,choices:d.choices.map(q=>({name:q.name,gap:q.clearance,risk:q.risk,wall:q.minWall})),hud:r.hud,clearance:r.clearance,direction:r.planOutput.name,exactImage:raw.decisionRing.frames.some(f=>f.seq===r.r65Seq),same:same&&{gap:same.clearance,risk:same.risk,wall:same.minWall},candidates:candidates.map(q=>({name:q.name,gap:q.clearance,risk:q.risk,wall:q.minWall})),bestGap:Math.max(...d.choices.map(q=>q.clearance))});}}
fs.writeFileSync('comparison.json',JSON.stringify(out,null,2));console.log('Saved '+out.length+' fixed states');
