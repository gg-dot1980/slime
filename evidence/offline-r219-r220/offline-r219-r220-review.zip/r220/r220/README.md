# r220 — feasible-exit contraction

Protocol fixed before replay: gap>3 and detected-wall margin>=20/3; at most2 exits for2 consecutive samples after>=4 within5, adjacent samples<=500ms. Missing walls remain unknown. Eight-direction model counts are not proof of physical exits. Lead target400ms before all threat gaps negative.

58 fixed states from3 prior runs. r218 warns681,403ms before683; warning682 also persists. Independent r209 wall case warns332 and337–340; these are repeated states in one episode, not independent trials. Seven success controls and six near-wall controls do not warn. r209 loses joint wall/threat feasibility at342 despite positive threat-only gaps, illustrating why threat count alone is insufficient. r218 wall geometry remains unknown. No steering change approved from these sparse cases.

## One bounded new desktop baseline
Confirmed prior r218 stopped and official preview stopped before starting owned preview. v2.20, Chromium, fixed2000 desktop. One start,0wins,0deaths,1manual abort after19.887 wall seconds,HUD04:40,size25. New capture failed with `wallPlan136 is not defined`: planner is private to controller closure. Zero accepted rows; no contraction inference from this run. One decision PNG hash and roundtrip verified,3periodic/terminal images,empty keysAfter,game pause visibly confirmed. Raw hash5e2f2b82de6f8438cf5c483ffb060896630b6580d5817ea459a1918b19c3177a. No replacement game within one-start limit.

## Reversible fix and regression
Original A.html/A-record.js/contraction.js retained. A-fixed.html exports only the existing image-observation planner as window.r220Plan; contraction-fixed.js uses that bridge; A-record-fixed.js prevents start without both capture and planner. Controller selection and200ms guard unchanged. Actual closure VM reproduces original error, then16fixed states preserve planInput/planOutput and expected warning; startup and stop protections checked. Browser validation of fix and live overhead remain pending, not claimed passed.

Reproduce: node r220/analyze.cjs; node r220/test.cjs; node r220/integration-test.cjs; node r220/stop-test.cjs. The first script requires prior local no-image result files and controller dependencies. Original raw and images remain local. To stage FIXED version, map A-fixed.html to r220A-trial.html, A-record-fixed.js to r220A-record-fixed.js and contraction-fixed.js to r220wall-capture.js; do not reuse old broken contraction.js. This staging has NOT been performed.

## Stop and next decision
No strategy A/B: observation integration failed. Verify fixed prerequisites in browser before a new bounded capture; preserve natural errors. Abandon count-only steering if independent warnings repeatedly lack an actionable alternative or harm successful-contact opportunities; do not lower thresholds for activation. Unknown walls are not free space. Full desktop version150second/50% acceptance unchanged; mobile skipped. Preview stopped, no GitHub retry/upload, no Library image upload, no OCR4 publication.
