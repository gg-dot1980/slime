const fs=require('fs'),assert=require('assert');process.chdir(__dirname);const rows=JSON.parse(fs.readFileSync('comparison.json'));
const get=(g,s)=>rows.find(r=>r.group===g&&r.seq===s);
assert.equal(rows.length,58);assert(get('development',678).signal);assert.deepEqual(get('development',678).candidates.map(x=>x.name),['東北']);assert.equal(get('development',678).exactImage,false);
assert(get('development',681).signal);assert.equal(get('development',681).candidates.length,0);
assert(!get('development',682).signal);assert(get('development',683).bestGap<0);
assert(get('wall-tradeoff',338).signal);assert.equal(get('wall-tradeoff',338).candidates.length,0);
for(const g of ['wall-top','wall-right','success1','success2'])assert(rows.filter(r=>r.group===g).every(r=>!r.signal));
for(const r of rows)for(const a of r.candidates){assert(a.gap>r.same.gap);assert(a.risk<=r.same.risk);if(a.wall!==null&&r.same.wall!==null)assert(a.wall>=r.same.wall);}
fs.writeFileSync('regression.json',JSON.stringify({passed:true,fixedStates:58,groups:6,developmentSignals:[678,681],independentSignal:338,eligibleSignal:678,successStatesUnchanged:7,wallEventStatesUnchanged:6,controllerModified:false,limitation:'wall null represents no detected wall / unbounded model, not measured free space; only a subplanner replay'},null,2));console.log('58 fixed states: expected signals, alternatives and controls verified');
