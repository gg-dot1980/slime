# r219 — bounded early-exit hypothesis experiment

Hypothesis and stop gate were saved in protocol.md before analysis. Replay uses the original r218 wallPlan136 implementation and saved observed objects, including supplementary objects, with recorded final direction as the comparator. It does not replay the complete stateful controller or infer hidden game state.

58 fixed states across three recorded runs: development r218675–690 (16), two wall-event windows (6), successful contacts r209229–232 and r161143–145 (7), independent wall tradeoff r209324–352 (29).

## Result
- r218678: three descending positive selected clearances95.54→92.52→60.95, HUD84 unchanged. Model NE clearance97.81 vs SW60.95 with lower risk. Only actionable signal; exact image missing, walls undetected. At677 selected SW has predicted gain5.80, so the preceding trajectory is not uniformly zero-reward.
- r218679–683: selected clearance75.60→47.76→39.66→39.71→−13.86. Directions S,S,NE,S,S. Signal681 has no eligible alternate; tiny rise682 suppresses the monotone signal. By683 all eight evaluated directions have negative minimum clearance.
- Independent wall338 warns but no alternate meets joint wall/risk/clearance requirements. Seven successful-contact and six wall-event controls are unchanged.
- Fixed regression confirms expected outcomes for58 states. This is limited model support for warning678, not evidence a changed action would survive or improve growth. No false-positive rate can be inferred from7 successful-contact states.

## Stop decision
No live A/B and no controller change: only one actionable development state, no independently actionable confirmation, its exact image absent and wall extent unknown. Do not label missing walls as measured safe space. Existing frame690 visibly supports crowding, not the unrecorded early NE path. The original r218 run is retained as0 wins/1 death135s; this experiment has0 new game starts.

Switch hypothesis to contraction of the entire feasible-direction set rather than a trend mixing selected trajectories; evaluate opportunity cost at676–678 and an independent actionable case. This is a proposed next hypothesis, not a validated improvement. No retuning or rerunning r218 in this round.

## Reproduce
From repository root: `node r219/analyze.cjs`, then `node r219/test.cjs`. source-hashes.json pins local sources/results. Local raw images are deliberately excluded from Git/upload; original result files are required. comparison.json is a no-image derived table. Shared preview untouched; GitHub restriction unchanged, no remote write. Mobile skipped; original desktop all-version150-second/50% threshold remains unmet and OCR4 unpublished.
