# Proposed r219/r220 offline reproduction batch — LOCAL REVIEW ONLY
Not uploaded, committed or pushed. Intended destination ONLY gg-dot1980/slime branch test/ocr-test, under evidence/offline-r219-r220/. No main/production change.
Source snapshots: r219=956ed215031df56ee7a89d0bf6835472552fadd1; r220=8932032b5c673c08baa4ad7fe82909b6dacbed9d.
42 explicit payload files are listed with size/SHA256/origin in ALLOWLIST.json. Full inputs are retained, no row reduction. r218/A-results-noimages.json is untracked source data, independently pinned to the hash in committed r219/source-hashes.json; do not describe it as a Git blob. Both snapshots include that exact full file.

Run with Node.js from extracted bundle directory:
```
(cd r219 && node r219/analyze.cjs && node r219/test.cjs)
(cd r220 && node r220/analyze.cjs && node r220/test.cjs && node r220/integration-test.cjs && node r220/stop-test.cjs)
```
Executed successfully in isolated directory; original Work repository was not modified. Generated comparison/regression outputs match committed hashes exactly. r219:58 fixed states; r220:58 fixed states, original closure error reproduced,16 fixed integration states and virtual stop/release checks passed. These are OFFLINE model/VM regressions, not browser or survival verification.

r220 live observation attempt was manually aborted after19.887s due to wallPlan136 undefined;0wins,0deaths,1abort,0accepted decisions. Fixed closure bridge has NOT been browser-validated. No replacement game run in this batch. Acceptance desktop versions <=150s >=50% remains unmet; no OCR4 release.

Scope: fixed offline reproduction only. The included HTML is read as source by VM; do not serve it as a complete browser deployment. Browser helper dependencies/assets are intentionally outside scope. No game starts or network access required for test commands. Recorded no-image JSON retains full metadata, not raster payloads; image-existence flags do not restore images.

AUDIT.json covers every payload file: UTF8 only, no binary/raster/SVG files; image data URI/base64 signatures, known credential formats, email patterns and recursive sensitive/pixel JSON keys checked with zero findings. No generalized scanner can guarantee absence of all unknown secrets. No .git, logs, private notes, raw-image JSON, credentials, browser state or unrelated files included.

Prior GitHub create_tree denial remains unresolved. This is an approval-review artifact, not permission to retry. Any external write requires appropriate verified authorization for repository,branch and exact allowlist, then normal policy review; no workaround is authorized.
