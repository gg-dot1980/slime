from pathlib import Path
import argparse,shutil
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();s=Path(__file__).resolve().parent;d=a.output;d.mkdir(parents=True,exist_ok=True)
for f,t in [('ring.js','r74-ring.js'),('fixture.html','r74-fixture.html'),('trial.html','r74-trial.html'),('record.js','r74-record.js'),('baseline/frame.js','r71-frame.js')]:shutil.copy(s/f,d/t)
(d/'r71-v2.20').mkdir(exist_ok=True);(d/'r71-v2.20/index.html').write_text((s/'baseline/game-source.html').read_text().replace('<script>','<script src="/r71-frame.js"></script><script>',1))
