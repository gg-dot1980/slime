from pathlib import Path
import shutil
p=Path(__file__).resolve().parent;s=p/'baseline'
ring=(s/'ring.js').read_text().replace('const events=[];','const events=[];let pinned=null,pinSeen=0,pinSkipped=0,pinMissing=0,pinCostMs=0;const pinMaxBytes=4*1024*1024;')
ring=ring.replace('stats(){return {cap,','pin(seq){pinSeen++;if(pinned){pinSkipped++;return false}const x=ring.find(x=>x.seq===seq);if(!x||x.status!=="accepted"||x.image.data.byteLength>pinMaxBytes){pinMissing++;return false}const t=performance.now();pinned={...x,capture:{...x.capture},image:new ImageData(new Uint8ClampedArray(x.image.data),x.image.width,x.image.height),intervention:true};pinCostMs=performance.now()-t;return true},stats(){return {pinSeen,pinSkipped,pinMissing,pinCostMs,pinMaxBytes,pinnedSeq:pinned?.seq??null,pinnedBytes:pinned?.image.data.byteLength??0,totalRawBytes:bytes+(pinned?.image.data.byteLength??0),cap,')
ring=ring.replace('for(const x of ring){const c=', 'for(const x of (pinned?[...ring.filter(x=>x.seq!==pinned.seq),pinned].sort((a,b)=>a.seq-b.seq):ring)){const c=')
ring=ring.replace('rows.push({seq:x.seq,','rows.push({intervention:!!x.intervention,seq:x.seq,')
(p/'ring.js').write_text(ring)
html=(s/'B.html').read_text().replace('r65-ring.js','r74-ring.js').replace('r72-B-record.js','r74-record.js');(p/'trial.html').write_text(html)
r=(s/'B-record.js').read_text().replace("version:'r72-B-fixed-desktop-v2.20'","version:'r74-record-only-fixed-desktop-v2.20'")
r=r.replace('x.r65Seq=window.r65Seq;','x.r65Seq=window.r65Seq;if(x.planOutput?.r72?.changed)window.r65Ring.pin(window.r65Seq);')
(p/'record.js').write_text(r)
assert html.replace('r74-ring.js','r65-ring.js').replace('r74-record.js','r72-B-record.js')==(s/'B.html').read_text()
print('controller HTML unchanged except recorder asset references')
