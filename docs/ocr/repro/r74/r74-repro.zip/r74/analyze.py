import json,hashlib,base64,sys
from pathlib import Path
p=Path(__file__).parent;source=Path(sys.argv[1]) if len(sys.argv)>1 else p/'raw-local.json';x=json.loads(source.read_text());sha=x.get('rawSha256') or hashlib.sha256(source.read_bytes()).hexdigest()
changes=[]
for i,r in enumerate(x['rows']):
 if r['planOutput'].get('r72',{}).get('changed'):
  f=next((f for f in x['decisionRing']['frames'] if f['seq']==r['r65Seq']),None)
  changes.append({'index':i,'seq':r['r65Seq'],'ms':r['ms'],'hudTime':r['hudTime'],'size':r['hud'],'baseline':r['planOutput']['r72']['baseline'],'chosen':r['planOutput']['name'],'clearance':r['clearance'],'gain':r['gain'],'imageAvailable':f is not None,'sameCapture':f['capture']==r['capture'] if f else None,'msToStop':x['stop']['ms']-r['ms']})
for f in x['decisionRing']['frames']:
 if f.get('intervention') and 'png' in f: (p/'intervention-local.png').write_bytes(base64.b64decode(f['png'].split(',')[1]))
y=json.loads(json.dumps(x))
for f in y['decisionRing']['frames']:f.pop('png',None)
for f in y['images']:f.pop('png',None)
y['rawSha256']=sha;(p/'results-noimages.json').write_text(json.dumps(y,indent=2)+'\n')
out={'stage':'r74','newStarts':1,'newWins':int(x['outcome']=='win'),'newDeaths':int(x['outcome']=='death'),'newAborts':int(x['outcome']=='aborted'),'seconds':x['seconds'],'size':x['stop']['size'],'outcome':x['outcome'],'rows':len(x['rows']),'rejected':len(x['rejected']),'missed':x['missed'],'keysAfter':x['keysAfter'],'ring':x['decisionRing']['stats'],'allPngRoundtrip':all(f['pngRoundtripEqual'] for f in x['decisionRing']['frames']),'changes':changes,'rawSha256':sha,'diagnosticOnly':True};(p/'summary.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
