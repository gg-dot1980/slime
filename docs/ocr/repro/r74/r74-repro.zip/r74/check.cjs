const fs=require('fs'),vm=require('vm'),assert=require('assert');let c={window:{},performance,ImageData:class{constructor(data,width,height){this.data=data;this.width=width;this.height=height}},Uint8ClampedArray};vm.createContext(c);vm.runInContext(fs.readFileSync('r74/ring.js','utf8'),c);const r=c.window.r65Ring;
const data=new Uint8ClampedArray(1200*698*4);data[0]=17;const seq=r.capture(new c.ImageData(data,1200,698),{start:1,end:2});assert(!r.pin(seq));r.associate(seq,'accepted',3);assert(r.pin(seq));data[0]=99;
for(let i=0;i<13;i++){let n=r.capture(new c.ImageData(new Uint8ClampedArray(data.length),1200,698),{start:i+4});r.associate(n,'accepted',i+5);assert(!r.pin(n));}
let stats=r.stats();assert.equal(stats.retained,12);assert.equal(stats.pinnedSeq,1);assert.equal(stats.pinSkipped,13);assert.equal(stats.pinMissing,1);assert.equal(stats.totalRawBytes,13*data.length);
// Recorder is downstream of move(d); only this observer hook differs.
let a=fs.readFileSync('r74/baseline/B-record.js','utf8'),b=fs.readFileSync('r74/record.js','utf8');b=b.replace("version:'r74-record-only-fixed-desktop-v2.20'","version:'r72-B-fixed-desktop-v2.20'").replace('if(x.planOutput?.r72?.changed)window.r65Ring.pin(window.r65Seq);','');assert.equal(a,b);
fs.writeFileSync('r74/check.json',JSON.stringify({stats,controllerUnchanged:true,recorderOnlyDelta:true},null,2));console.log(stats);

// Separate rejection/oversize/no-intervention scenario.
let z={window:{},performance,ImageData:c.ImageData,Uint8ClampedArray};vm.createContext(z);vm.runInContext(fs.readFileSync('r74/ring.js','utf8'),z);let q=z.window.r65Ring;let k=q.capture(new c.ImageData(new Uint8ClampedArray(4*1024*1024+4),1,1),{});q.associate(k,'accepted',1);assert(!q.pin(k));assert.equal(q.stats().pinnedBytes,0);assert.equal(q.stats().pinMissing,1);assert.equal(q.stats().retained,1);console.log('oversize pin rejected without replacing retained frame');
