import json,hashlib
from pathlib import Path
from PIL import Image
p=Path(__file__).parent;x=json.load(open(p.parent/'r77/B-results-noimages.json'));out=[]
for f in x['decisionRing']['frames']:
 a=Image.open(p/(str(f['seq'])+'-local.png')).convert('RGBA');b=a.tobytes();h=hashlib.sha256(b).hexdigest();assert h==f['rawHash'];(p/(str(f['seq'])+'-local.rgba')).write_bytes(b);out.append({'seq':f['seq'],'width':a.width,'height':a.height,'rawHash':h,'decision':x['rows'][f['seq']-1]})
(p/'inputs.json').write_text(json.dumps(out,indent=2)+'\n')
