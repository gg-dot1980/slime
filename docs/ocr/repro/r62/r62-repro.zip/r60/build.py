from pathlib import Path
import json,hashlib
p=Path(__file__).resolve().parent;root=p.parent
html=(root/'portable-r46-r50/r50-game.html').read_text();original=html[html.index('function plan('):html.index('\nlet lastVision')];cand=(p/'candidate.js').read_text();cand=cand[cand.index('function plan('):]
cand=cand.replace('const safe=candidates.filter','const r60={active:!!context,unconfirmed:objects.filter(o=>!o.npc&&!confirmed(o)).length};const safe=candidates.filter').replace('return {...pool[0],escaping:','return {...pool[0],r60,escaping:')
for name,body in [('A',original),('B',cand)]:
 h=html.replace(original,body).replace('r50-record.js','r60-'+name+'-record.js').replace('r50 bounded telemetry diagnostic','r60-'+name+' confirmation trial')
 if name=='B':
  h=h.replace('function tick(runId)', 'let r60Previous=null;\nfunction tick(runId)',1)
  old='const d=plan(objects,hud,analysis.map,speed,velocity,heading,splitGuard);'
  new='const audit=window.r50audit,context=r60Previous&&r60Previous.time===audit.priorTimestamp&&audit.measuredCamera&&audit.shiftCount>=3&&audit.dt<=.4?{previous:r60Previous.objects,cameras:[audit.camera,audit.npcCamera],dt:audit.dt}:null;r60Previous={time:audit.now,objects:JSON.parse(JSON.stringify(objects))};planInput.confirmation=context;const d=plan(objects,hud,analysis.map,speed,velocity,heading,splitGuard,context);'
  assert old in h;h=h.replace(old,new)
 (p/('r60-'+name+'.html')).write_text(h)
 (p/('r60-'+name+'-record.js')).write_text((root/'portable-r46-r50/r50-record.js').read_text().replace('recovery-r50-telemetry-test043','r60-'+name+'-test043'))
(p/'plan.json').write_text(json.dumps({'hypothesis':'Requiring one prior compatible food observation under both recorded camera estimates prevents intermittent food target switches; keep NPC/risks and predicted path gains unchanged.','association':'existing100px matching range,max(6,r*.2)radius;bothcameraestimates;only>=3measuredshifts,dt<=.4,and exact prior timestamp. Not physical identity truth.','batch':'fixed A then B,one v2.20 desktop each,150HUDseconds/210wallseconds/3stale/800rows;no replacements','limits':'test exploratory,not acceptance;some modeled margin reductions;randomseedsunknown','images':'localonly'},indent=2))
