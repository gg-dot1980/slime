from pathlib import Path
import json,math,hashlib
root=Path(__file__).resolve().parent.parent;p=root/'r60';data=json.loads((root/'r57/B-results-noimages.json').read_text());rs=data['rows'];out=[]
for i in range(1,len(rs)):
 a=rs[i];old=rs[i-1]['target'];t=a['target'];m=a['telemetry']
 if not old or not t or old.get('mapOnly') or t.get('mapOnly'):continue
 models={}
 for name in ['camera','npcCamera']:
  cam=m[name];dt=m['dt'];ex=old['x']+(old.get('vx',0)-cam['x'])*dt;ey=old['y']+(old.get('vy',0)-cam['y'])*dt
  near=sorted([(math.hypot(q['x']-ex,q['y']-ey),j) for j,q in enumerate(a['objects']) if q['npc']==old['npc'] and abs(q['r']-old['r'])<=max(6,old['r']*.2)])
  models[name]={'residual':near[0][0] if near else None,'index':near[0][1] if near else None,'secondResidual':near[1][0] if len(near)>1 else None,'selectedResidual':math.hypot(t['x']-ex,t['y']-ey)}
 food=not t['npc'];threats=[q for q in a['objects'] if q['npc'] and not q['clipped'] and (q['isRed'] or q['r']>=a['hud']*.98)]
 enclosed=any(math.hypot(t['x']-q['x'],t['y']-q['y'])+(a['hud']+t['r']*.5)<.75*(a['hud']+(max(q['r'],a['hud']*1.1) if q['isRed'] else q['r']))+12 for q in threats) if food else None
 out.append({'index':i,'ms':a['ms'],'hud':a['hud'],'direction':a['planOutput']['name'],'oldTarget':old,'target':t,'models':models,'branch':m['branch'],'dt':m['dt'],'cameraDisagreementPx':math.hypot(m['camera']['x']-m['npcCamera']['x'],m['camera']['y']-m['npcCamera']['y'])*m['dt'],'targetContactDiskEnclosed':enclosed})
focus=[x for x in out if x['index'] in [195,196,197,256,257,258,259,260,261,262,263,264,265]]
summary={'rows':len(rs),'comparableTransitions':len(out),'focus':focus,'scope':'nearest compatible detection is not ground-truth identity; no colors/physical IDs in saved planInput','newGames':0}
(p/'result.json').write_text(json.dumps(summary,indent=2))
print(json.dumps([{'i':x['index'],'hud':x['hud'],'cameraDeltaPx':round(x['cameraDisagreementPx'],1),'residuals':{k:round(v['residual'],1) if v['residual'] is not None else None for k,v in x['models'].items()},'enclosed':x['targetContactDiskEnclosed']} for x in focus],indent=2))
