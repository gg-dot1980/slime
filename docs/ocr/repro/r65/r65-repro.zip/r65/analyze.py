import json,hashlib,statistics,sys
from pathlib import Path
src=Path(sys.argv[1]);d=json.loads(src.read_text());frames=d['decisionRing']['frames'];rows={r['r65Seq']:r for r in d['rows']};associated=[]
for f in frames:
 r=rows.get(f['seq']);associated.append({'seq':f['seq'],'status':f['status'],'matchedAccepted':r is not None,'timestampExact':r['capture']==f['capture'] if r else None,'decisionMsExact':r['ms']==f['decisionMs'] if r else None,'roundtripEqual':f['pngRoundtripEqual'],'toStopMs':d['stop']['ms']-f['capture']['end']})
summary={'id':d['id'],'version':d['version'],'game':d['game'],'startedAt':d['startedAt'],'ua':d['ua'],'canvas':d['canvas'],'css':d['css'],'dpr':d['dpr'],'outcome':d['outcome'],'seconds':d['seconds'],'size':d['stop']['size'],'reason':d['reason'],'rows':len(d['rows']),'rejections':len(d['rejected']),'periodicAndTerminalImages':len(d['images']),'missed':d['missed'],'keysAfter':d['keysAfter'],'ring':d['decisionRing']['stats'],'association':associated,'computeMedianMs':statistics.median(r['elapsedCompute'] for r in d['rows']),'computeMaxMs':max(r['elapsedCompute'] for r in d['rows']),'rawSha256':hashlib.sha256(src.read_bytes()).hexdigest(),'newStarts':1,'newWins':int(d['outcome']=='win'),'newDeaths':int(d['outcome']=='death'),'newAborts':int(d['outcome']=='aborted')}
Path('r65/live-summary.json').write_text(json.dumps(summary,indent=2))
for f in frames:f.pop('png',None)
d['imageMetadata']=[{k:v for k,v in x.items() if k!='png'} for x in d.pop('images')];d['rawSha256']=summary['rawSha256'];Path('r65/live-results-noimages.json').write_text(json.dumps(d,separators=(',',':')))
print(json.dumps(summary,indent=2))
