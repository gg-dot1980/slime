from pathlib import Path
import argparse,shutil
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();root=Path(__file__).resolve().parent.parent;out=a.output;out.mkdir(parents=True,exist_ok=True)
s=(root/'portable-r46-r50/r50-game.html').read_text();s=s.replace('<title>', '<title>r65 ',1);needle='const prior=imageState;';assert needle in s;s=s.replace(needle,'window.r65Seq=window.r65Ring.capture(image,window.r4capture);'+needle,1)
s=s.replace('<script>', '<script src="r65-ring.js"></script><script>',1)
r=(root/'portable-r46-r50/r50-record.js').read_text();r=r.replace("rejected.push(x);", "window.r65Ring.associate(window.r65Seq,'rejected',x.ms);rejected.push(x);")
r=r.replace('rows.push(JSON.parse', "window.r65Ring.associate(window.r65Seq,'accepted',x.ms);x.r65Seq=window.r65Seq;rows.push(JSON.parse")
r=r.replace("const d=doc(),title=", "const decisionRing=await window.r65Ring.finish();const d=doc(),title=")
r=r.replace('keysAfter:[...held],rejected', 'decisionRing,keysAfter:[...held],rejected').replace("version:'recovery-r50-telemetry-test043'", "version:'r65-ring-test043'")
r=r.replace('rows:rows.length,images:images.length,keys:keys.length','decisionRing:{stats:decisionRing.stats,frames:decisionRing.frames.map(({png,...v})=>v)},rows:rows.length,images:images.length,keys:keys.length')
s=s.replace('r50-record.js','r65-record.js');(root/'r65/game.html').write_text(s);(root/'r65/record.js').write_text(r)
for src,dst in [(root/'r65/ring.js','r65-ring.js'),(root/'r65/game.html','r65.html'),(root/'r65/record.js','r65-record.js')]:shutil.copy(src,out/dst)

shutil.copytree(root/"portable-r46-r50/v2.20",out/"v2.20",dirs_exist_ok=True)
for name,dst in [("probe.html","r65-probe.html"),("probe-source.js","r65-probe-source.js")]:shutil.copy(root/"r65"/name,out/dst)
shutil.copy(root/"r45-source/Current.js",out/"r64-original.js")
