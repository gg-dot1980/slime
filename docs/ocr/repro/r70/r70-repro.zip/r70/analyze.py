import json,math
from pathlib import Path
P=Path('r70');inputs=json.load(open('r70/inputs.json'));results=json.load(open('r70/frozen-candidates.json'));errors=json.load(open('r70/error-inputs.json'));rate=-math.log(.65)/.1
# Frozen prefix scenarios, not measured bounds; continuous-equivalent inertia and unchanged radius.
def advance(v,goal,dt):
 e=math.exp(-rate*dt);return goal*dt+(v-goal)*(1-e)/rate,goal+(v-goal)*e
names=['東','東南','南','西南','西','西北','北','東北']
def path(p,name,delay):
 a=names.index(name)*math.pi/4;d=[math.cos(a),math.sin(a)];old=[p['heading']['x'],p['heading']['y']];pos=[0,0];v=[p['velocity']['x'],p['velocity']['y']];wall=1e6;gap=1e6
 times=sorted(set([0,delay]+[i/10 for i in range(1,21)]));last=0
 for t in times[1:]:
  goal=old if last<delay-1e-9 else d
  for j in range(2):
   delta,v[j]=advance(v[j],goal[j]*p['speed'],t-last);pos[j]+=delta
  for j,w in enumerate(p['map'].get('visibleWalls',[]) if p.get('map') else []):
   if w!=None:wall=min(wall,w+[pos[0],-pos[0],pos[1],-pos[1]][j]-p['hud'])
  if t<=1.1000001:
   for o in p['objects']:
    if not o['npc'] or not o['clipped'] and not o['isRed'] and o['r']<p['hud']*.98:continue
    body=o['dangerRadius'] if o['clipped'] else max(o['r'],p['hud']*1.1) if o['isRed'] else o['r'];gap=min(gap,math.hypot(o['x']+o['vx']*t-pos[0],o['y']+o['vy']*t-pos[1])-.75*(p['hud']+body)-12)
  last=t
 return {'wall':wall,'npcGap':gap}
cases=[]
for i in [180,181]:
 r=errors['B']['rows'][str(i)];n=errors['B']['rows'][str(i+1)];p=r['planInput'];dt=(n['capture']['end']-r['capture']['end'])/1000;offset=(r['recordAt']-r['capture']['end'])/1000;old=p['heading']['x']*p['speed'];new=r['direction']['x']*p['speed'];v=p['velocity']['x'];a,v1=advance(v,old,min(offset,dt));b,_=advance(v1,new,max(0,dt-offset));immediate,_=advance(v,new,dt);obs=n['map']['visibleWalls'][0]-r['map']['visibleWalls'][0];cases.append({'index':i,'recordOffsetMs':offset*1000,'sameOldNewDirection':p['heading']['x']==r['direction']['x'] and p['heading']['y']==r['direction']['y'],'immediate':immediate,'recordAsSwitchSensitivity':a+b,'observed':obs,'prefixResidual':obs-a-b})
rows=[]
for r in results['rows']:
 if not r['group'].startswith('holdout-') or not r['change']:continue
 p=inputs[r['group']][str(r['index'])]['planInput']
 for delay in [0,.1,.2]:
  a=path(p,r['baseline']['name'],delay);b=path(p,r['candidate']['name'],delay);rows.append({'group':r['group'],'index':r['index'],'delay':delay,'baseline':a,'candidate':b,'npcLoss':b['npcGap']-a['npcGap'],'wallLoss':b['wall']-a['wall']})
summary={str(d):{'pairs':len([r for r in rows if r['delay']==d]),'npcMarginDecreases':sum(r['npcLoss']<-1e-8 for r in rows if r['delay']==d),'newNegativeNpcGap':sum(r['baseline']['npcGap']>=0 and r['candidate']['npcGap']<0 for r in rows if r['delay']==d),'negativeCandidateWall':sum(r['candidate']['wall']<0 for r in rows if r['delay']==d),'worstNpcLoss':min(r['npcLoss'] for r in rows if r['delay']==d)} for d in [0,.1,.2]}
(P/'results.json').write_text(json.dumps({'timingCases':cases,'summary':summary,'rows':rows},indent=2));print(json.dumps({'timingCases':cases,'summary':summary},indent=2))
