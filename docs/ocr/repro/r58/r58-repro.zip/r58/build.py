from pathlib import Path
import json
p=Path(__file__).resolve().parent;root=p.parent
s=(root/'r45-source/Current.js').read_text();start=s.index('function plan(');end=s.index('\nlet lastVision');original=s[start:end]
needle='return {...pool[0],escaping:'
insert="""const winner=pool[0],prior=pool.find(d=>d.x*old.x+d.y*old.y>.99),reverse=winner.x*old.x+winner.y*old.y<-.5;const hold=!!(safe.length&&reverse&&prior&&prior.clearance>3&&winner.score-prior.score<=1.8);const selected=hold?prior:winner;return {...selected,r58:{changed:hold,reverse,scoreAdvantage:prior?winner.score-prior.score:null,original:winner.name,originalClearance:winner.clearance},escaping:"""
assert needle in original
candidate=original.replace(needle,insert)
(p/'controller.js').write_text('window.makeR58=()=>{'+s[s.index('const dirs='):start]+original.replace('function plan(','function baseline(',1)+candidate+';return {plan,baseline}};')
html=(root/'portable-r46-r50/r50-game.html').read_text();origHtml=html[html.index('function plan('):html.index('\nlet lastVision')]
for name,body in [('A',origHtml),('B',candidate)]:
 (p/(name+'.html')).write_text(html.replace(origHtml,body).replace('r50-record.js',name+'-record.js'))
 (p/(name+'-record.js')).write_text((root/'portable-r46-r50/r50-record.js').read_text().replace('recovery-r50-telemetry-test043','r58-'+name+'-test043'))
(p/'plan.json').write_text(json.dumps({'hypothesis':'Avoid immediate >120-degree reversal when prior direction remains in original eligible pool and score deficit <=1.8 (one nominal food gain .45*4). Preserve all-unsafe fallback and original safe/bounded pool.','frozenThreshold':1.8,'validation':'r57 A/B 941 frozen inputs plus1298 historical originals and415 conditional separately; report margin loss and prior clearance, all-unsafe unchanged','live':'only if meaningful coverage and no invalid-pool selection, fixed A then B v2.20 desktop one each;150 HUDseconds/210wallseconds; no replacement of death/abort; random seeds unknown','limits':'one-step frozen replay not closed-loop safety or win-rate evidence; threshold not tuned on holdout','images':'local only'},indent=2))
