from pathlib import Path
import json,hashlib,re
p=Path(__file__).parent;out=[]
for f in sorted((p/'rules').glob('*.html')):
 s=f.read_text();version=re.search(r'SLIME ARENA · (v2\.\d+)',s).group(1)
 assert 'else if(s.r>player.r*1.08)s.target={x:player.x,y:player.y,chase:true}' in s
 assert 'if(player.r>=s.r*1.08)' in s and 'else if(s.r>=player.r*1.08)' in s and 'contact=(player.r+s.r)*.72' in s
 assert 's.think=rand(.55,.9)' in s
 cases=[]
 for nr in [90,92,93,99,100,101,107,108,109,120]:
  result='eat' if 100>=nr*1.08 else 'death' if nr>=100*1.08 else 'neutral';cases.append({'player':100,'npc':nr,'contactOutcome':result})
 assert [v['contactOutcome'] for v in cases]==['eat','eat','neutral','neutral','neutral','neutral','neutral','death','death','death']
 out.append({'version':version,'path':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'sourceCommit':'5a1aca6442194b6348ed5554eb65f827026811c3','chaseAtSelection':'npc>player*1.08; not chase truth from apparent approach','retargetSeconds':[.55,.9],'contactDistance':'distance < .72*(player+NPC radius)','eat':'player>=NPC*1.08','death':'NPC>=player*1.08','neutral':'player/1.08 < NPC < player*1.08','cases':cases,'limitations':'Source-rule numeric checks only, not new live tests; true radii unavailable to controller; growth/split or stale target can change classification during overlap.'})
(p/'rules-results.json').write_text(json.dumps(out,indent=2)+'\n');print('4versions,40 source-rule cases passed')
