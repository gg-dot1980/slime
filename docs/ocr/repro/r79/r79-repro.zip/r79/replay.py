from pathlib import Path
import json
p=Path(__file__).parent;a=json.loads((p/'results.json').read_text());h=json.loads((p/'holdout-results.json').read_text());npc=[r for r in a if r['source']=='B' and r.get('npc')];assert len(npc)==9 and all(not r['checks']['areaHigh'] and r['area']>=4 for r in npc);assert all(r['eligible']==1 and r['isolated']>r['part']['r'] for r in npc);assert len(h)==52 and not any(r['eligible'] for r in h);assert all(r['newRadius']>=r['oldRadius'] for r in h);print('9 recovered fixed targets;52 independent labelled objects unchanged; numeric replay passed')
