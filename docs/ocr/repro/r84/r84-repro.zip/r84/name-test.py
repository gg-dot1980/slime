from pathlib import Path
import json,time,statistics,hashlib
import numpy as np
from PIL import Image
p=Path(__file__).parent;root=p.parent;data=json.load(open(root/'r80/B-results-noimages.json'));samples=[]
# Fixed image-verified track labels; geometric ROI lookup is not tested object detection.
for r in data['rows']:
 if not 304<=r['r65Seq']<=312:continue
 for label,pred in [('小橘',lambda o:o['npc'] and not o['clipped'] and 70<o['r']<90 and o['x']>0 and o['y']<0),('泡泡',lambda o:o['npc'] and not o['clipped'] and 40<o['r']<65 and o['x']>0 and 0<o['y']<180),('啵啵',lambda o:o['npc'] and not o['clipped'] and 40<o['r']<65 and o['x']>0 and 180<o['y']<450)]:
  objects=[o for o in r['objects'] if pred(o)];assert len(objects)==1,(r['r65Seq'],label,len(objects));o=objects[0];samples.append({'seq':r['r65Seq'],'label':label,'x':600+o['x']*.6,'y':349+o['y']*.6,'path':'r81/'+str(r['r65Seq'])+'-local.png','role':'dev' if r['r65Seq']==304 else 'heldout'})
samples += [{'seq':25,'label':'QQ','x':809,'y':152,'path':'r80/B-first-correction-local.png','role':'unknown-name-control'},{'seq':25,'label':'果凍','x':735,'y':108,'path':'r80/B-first-correction-local.png','role':'unknown-name-control'}]
def feature(im,x,y):
 a=np.asarray(im.crop((round(x)-20,round(y)-7,round(x)+21,round(y)+8))).astype('int16');mask=(a[:,:,:3].min(2)>200)&((a[:,:,:3].max(2)-a[:,:,:3].min(2))<40);yy,xx=np.where(mask)
 if len(xx)<4:return None,int(mask.sum())
 crop=mask[yy.min():yy.max()+1,xx.min():xx.max()+1];f=np.asarray(Image.fromarray(crop).resize((32,16),Image.Resampling.NEAREST)).astype(bool);return f,int(mask.sum())
def similarity(a,b):return 2*np.count_nonzero(a&b)/max(1,np.count_nonzero(a)+np.count_nonzero(b))
images={n:Image.open(root/n).convert('RGB') for n in {s['path'] for s in samples}};templates={};rows=[]
for s in samples:
 t=time.perf_counter();f,n=feature(images[s['path']],s['x'],s['y'])
 if s['role']=='dev':templates[s['label']]=f;continue
 scores=sorted([(name,similarity(f,v)) for name,v in templates.items()],key=lambda a:-a[1]) if f is not None else [];pred=scores[0][0] if scores and scores[0][1]>=.75 and scores[0][1]-scores[1][1]>=.10 else None
 rows.append({**s,'pixels':n,'scores':scores,'prediction':pred,'correct':pred==s['label'],'ms':(time.perf_counter()-t)*1000})
summary={}
for role in ['heldout','unknown-name-control']:
 rs=[r for r in rows if r['role']==role];summary[role]={'n':len(rs),'correct':sum(r['correct'] for r in rs),'wrongAccepted':sum(r['prediction'] is not None and not r['correct'] for r in rs),'unknown':sum(r['prediction'] is None for r in rs)}
times=[r['ms'] for r in rows];out={'summary':summary,'timeMs':{'median':statistics.median(times),'max':max(times)},'rows':rows,'imageHashes':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in images},'limits':'Three templates only; manually labelled same-game correlated tracks, ROIs aided by saved detections; cached-image CPU timing not browser overhead; no identity truth or radius inferred'}
(p/'annotations.json').write_text(json.dumps(samples,ensure_ascii=False,indent=2));(p/'results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ['rows','imageHashes']},ensure_ascii=False,indent=2))
