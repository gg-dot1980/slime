from pathlib import Path
import json,re,hashlib
p=Path(__file__).parent;out=[]
for f in sorted((p.parent/'r83/rules').glob('*.html')):
 s=f.read_text();draw=next(l for l in s.splitlines() if l.startswith('function drawSlime'));add=next(l for l in s.splitlines() if l.startswith('function addNpc'));assert "[t('泡泡'),t('啵啵'),t('果凍'),'QQ',t('藍莓'),t('小橘')][Math.floor(rand(0,6))]" in add;assert 'Math.max(10,Math.min(13,s.r*.32))' in draw
 calls=re.findall(r'ctx.fillText\([^;]+',draw);assert len(calls)==2 and calls[0]=='ctx.fillText(s.name,x,y+4)'
 out.append({'version':re.search(r'SLIME ARENA · (v2\.\d+)',s).group(1),'sourceCommit':'5a1aca6442194b6348ed5554eb65f827026811c3','file':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'names':['泡泡','啵啵','果凍','QQ','藍莓','小橘'],'selection':'random independent of radius; duplicates permitted','NPCTextCalls':calls,'fontCSS':'clamp(radius*.32,10,13)','fontAnalysisPixelsAtScale0_6':[6,7.8],'radiusText':False,'nameUnique':False})
(p/'source-results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print('four source versions verified')
