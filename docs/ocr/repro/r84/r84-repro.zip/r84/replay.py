from pathlib import Path
import json
p=Path(__file__).parent;x=json.load(open(p/'results.json'));counts={}
for role in ['heldout','unknown-name-control']:
 rows=[r for r in x['rows'] if r['role']==role]
 for r in rows:
  s=r['scores'];prediction=s[0][0] if s and s[0][1]>=.75 and s[0][1]-s[1][1]>=.10 else None
  assert prediction==r['prediction']
 counts[role]={'n':len(rows),'correct':sum(r['prediction']==r['label'] for r in rows),'wrongAccepted':sum(r['prediction'] is not None and r['prediction']!=r['label'] for r in rows),'unknown':sum(r['prediction'] is None for r in rows)}
assert counts==x['summary'];print(counts)
