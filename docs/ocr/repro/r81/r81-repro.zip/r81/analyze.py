from pathlib import Path
import json,hashlib,math
p=Path(__file__).parent
x=json.loads((p/'inputs.json').read_text());rows=x['rows'];frames={f['seq']:f for f in x['frames']};out=[]
for r in rows:
 seq=r['r65Seq'];changes=[a for a in r['radiusAudit']['rows'] if a['changed']];near=sorted([o for o in r['objects'] if o['npc']],key=lambda o:o['r'],reverse=True)
 out.append({'seq':seq,'capture':r['capture'],'hud':r['hud'],'dir':r['planOutput']['name'],'escaping':r['planOutput']['escaping'],'clearance':r['clearance'],'computeMs':r['elapsedCompute'],'corrections':changes,'hasSameFrameImage':seq in frames,'rightWall':r['map'].get('visibleWalls',[None]*4)[1],'largest':near[0],'nearby':sorted([o for o in near if math.hypot(o['x'],o['y'])<350],key=lambda o:math.hypot(o['x'],o['y']))})
last=[r for r in out if r['seq']>=301];gaps=[b['capture']['start']-a['capture']['start'] for a,b in zip(last,last[1:])];reversals=[b['seq'] for a,b in zip(last,last[1:]) if a['dir']!=b['dir']];report={'hypothesis':'Final direction reversals are not caused by same-frame radius corrections: three late corrections keep prey classification and do not change direction in the fixed ablation; earlier unpictured effects remain unknown.','lastFrameCount':len(last),'lastCorrectionCount':sum(len(r['corrections']) for r in last),'reversals':reversals,'escapingFrames':[r['seq'] for r in last if r['escaping']],'captureIntervalMs':{'min':min(gaps),'max':max(gaps)},'lastCaptureToTerminalMs':x['terminal']['ms']-last[-1]['capture']['end'],'missingChangeImages':[r['seq'] for r in out if r['seq'] in [271,285] and not r['hasSameFrameImage']],'rows':out,'limits':['no inferred killer','radii and velocity are estimates','terminal HUD60to67 plus missing purple is consistent with swallowing but object attribution unknown','same-frame radius ablation retains B tracking history, not counterfactual gameplay']}
assert len(last)==12 and report['lastCorrectionCount']==3 and report['reversals']==[304,307,310,311]
assert report['missingChangeImages']==[271,285]
report['lateCorrectionAblation']=[r for r in x['impact']['rows'] if r['seq']>=301]
assert all(not r['directionChanged'] and all(m['wasEdible']==m['nowEdible'] for m in r['matches']) for r in report['lateCorrectionAblation'])
(p/'results.json').write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items() if k!='rows'})
