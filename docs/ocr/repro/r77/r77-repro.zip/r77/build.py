from pathlib import Path
p=Path(__file__).resolve().parent;a=(p/'A-plan.js').read_text();needle='return {...chosen,r72:'
b=a.replace(needle,'const priorChoice=chosen;if(!(base.risk>0||base.minWall<margin))chosen=base;return {...chosen,r77:{changedVsA:chosen!==priorChoice,priorName:priorChoice.name},r72:');assert b!=a;(p/'B-plan.js').write_text(b)
t=(p/'template.html').read_text();start=t.index('function prefixMetric(');end=t.index('\nlet lastVision',start)
for g in ['A','B']:
 html=t[:start]+(p/(g+'-plan.js')).read_text()+t[end:];html=html.replace('r74-ring.js','r77-ring.js').replace('r74-record.js','r77-'+g+'-record.js');(p/(g+'.html')).write_text(html)
 r=(p/'record-template.js').read_text().replace('r74-record-only-fixed-desktop-v2.20','r77-'+g+'-fixed-desktop-v2.20').replace('x.planOutput?.r72?.changed','(x.planOutput?.r72?.changed||x.planOutput?.r77?.changedVsA)');(p/(g+'-record.js')).write_text(r)
