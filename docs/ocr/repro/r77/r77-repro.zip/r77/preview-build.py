from pathlib import Path
import argparse,shutil
z=argparse.ArgumentParser();z.add_argument('--output',type=Path,required=True);a=z.parse_args();p=Path(__file__).resolve().parent;d=a.output;d.mkdir(parents=True,exist_ok=True)
for g in ['A','B']:
 shutil.copy(p/(g+'.html'),d/('r77-'+g+'.html'));shutil.copy(p/(g+'-record.js'),d/('r77-'+g+'-record.js'))
shutil.copy(p/'ring.js',d/'r77-ring.js');shutil.copy(p/'frame.js',d/'r71-frame.js');(d/'r71-v2.20').mkdir(exist_ok=True);(d/'r71-v2.20/index.html').write_text((p/'game-source.html').read_text().replace('<script>','<script src="/r71-frame.js"></script><script>',1))
