import json,math,statistics
from pathlib import Path
out=[]
for g,indices in [('A',[425]),('B',[180,181,263,264,289,284])]:
 d=json.load(open('r69/error-inputs.json'))[g]
 for i in indices:
  r=d['rows'][str(i)];n=d['rows'][str(i+1)];p=r['planInput'];dt=(n['capture']['end']-r['capture']['end'])/1000;v=p['velocity']['x'];goal=r['direction']['x']*p['speed'];k=-math.log(.65)/.1;pred=goal*dt+(v-goal)*(1-math.exp(-k*dt))/k;obs=n['map']['visibleWalls'][0]-r['map']['visibleWalls'][0] if n['map']['visibleWalls'][0]!=None else None
  near=min(d['imageMetadata'],key=lambda im:abs(im['ms']-r['ms']));out.append({'group':'r60-'+g,'index':i,'wall':p['map']['visibleWalls'][0],'radius':p['hud'],'nearContact':p['map']['visibleWalls'][0]<=p['hud']+20/3,'dt':dt,'observedLeftWallDelta':obs,'predictedDelta':pred,'residual':None if obs==None else obs-pred,'nearestSavedImageOffsetMs':near['ms']-r['ms'],'recordOffsetMs':r['recordAt']-r['capture']['end']})
report={'scope':'First6 are margin-decrease cases; B284 is separate low-remainder improvement. Residual mixes model, sensing, unknown actuation and camera; not pure measurement error or calibrated bound. Full next intervals, not chosen to fit.','cases':out,'absResidualMedian':statistics.median(abs(a['residual']) for a in out[:6] if a['residual']!=None),'absResidualMax':max(abs(a['residual']) for a in out[:6] if a['residual']!=None)}
Path('r69/errors.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
