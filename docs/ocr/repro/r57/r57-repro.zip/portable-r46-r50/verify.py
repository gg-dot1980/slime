import json,hashlib
from pathlib import Path
m=json.load(open('SHA256.json'))
for p,h in m.items():
 assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
print('Verified',len(m),'file hashes')
