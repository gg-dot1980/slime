from pathlib import Path
import json,hashlib,zipfile,sys
p=Path(__file__).resolve().parent;root=p.parent
files=[x for x in p.iterdir() if x.is_file() and x.suffix in ['.js','.cjs','.py','.html','.md','.json'] and 'local' not in x.name and x.name not in ['manifest.json','archive.json']]
files += [root/'r79'/n for n in ['results.json','holdout-results.json']]
for x in files:
 b=x.read_bytes();import re;assert not re.search(rb'data:image/(?:png|jpeg|webp);base64,[A-Za-z0-9+/=]{80,}',b),x
 if x.suffix=='.json':
  def check(v):
   if isinstance(v,dict):
    assert not v.get('png'),x
    for a in v.values():check(a)
   elif isinstance(v,list):
    for a in v:check(a)
  check(json.loads(b))
manifest={str(x.relative_to(root)):hashlib.sha256(x.read_bytes()).hexdigest() for x in files};(p/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(p/'r80-repro.zip','w',zipfile.ZIP_DEFLATED) as z:
 for x in files+[p/'manifest.json']:z.write(x,str(x.relative_to(root)))
f=p/'r80-repro.zip';out={'file':f.name,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'entries':len(files)+1};(p/'archive.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
