from pathlib import Path
import json,statistics,collections
p=Path(__file__).parent

def dist(v):
 v=sorted(v)
 return {'n':len(v),'median':statistics.median(v),'p95':v[min(len(v)-1,int(len(v)*.95))],'max':v[-1]} if v else None
out={}
for g in ['A','B']:
 x=json.loads((p/(g+'-results-noimages.json')).read_text());rows=x['rows']+x['rejected'];frames={f['seq'] for f in x['decisionRing']['frames']};audits=[r.get('radiusAudit') or {} for r in rows];calls=[v for a in audits for v in a.get('rows',[])];changes=[{'seq':r.get('r65Seq'),'hudTime':r.get('hudTime'),'hud':r.get('hud'),'imageAvailable':r.get('r65Seq') in frames,'rows':[v for v in (r.get('radiusAudit') or {}).get('rows',[]) if v['changed']]} for r in rows if any(v['changed'] for v in (r.get('radiusAudit') or {}).get('rows',[]))]
 out[g]={'frames':len(rows),'missingAudit':sum('radiusAudit' not in r for r in rows),'emptyAuditFrames':sum(not a.get('rows') for a in audits),'dropped':sum(a.get('dropped',0) for a in audits),'sources':dict(collections.Counter(v['source'] for v in calls)),'changedCalls':sum(v['changed'] for v in calls),'changedFrames':len(changes),'costPerCallMs':dist([v['costMs'] for v in calls]),'summedCostPerFrameMs':dist([sum(v['costMs'] for v in a.get('rows',[])) for a in audits]),'acceptedComputeMs':dist([r['elapsedCompute'] for r in x['rows']]),'rejectedComputeMs':dist([r['elapsedCompute'] for r in x['rejected'] if 'elapsedCompute' in r]),'changes':changes,'warning':'radius estimates are not truth; empty audit may be cache; game-to-game timing not paired overhead'}
(p/'provenance.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({g:{k:v for k,v in s.items() if k!='changes'} for g,s in out.items()},indent=2))
