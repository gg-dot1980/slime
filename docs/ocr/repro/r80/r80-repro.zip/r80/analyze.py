from pathlib import Path
import json,hashlib,sys
p=Path(__file__).parent;g=sys.argv[1];source=Path(sys.argv[2]);x=json.loads(source.read_text());sha=x.get('rawSha256') or hashlib.sha256(source.read_bytes()).hexdigest()
def elapsed(r):
 try:a,b=map(int,r['hudTime'].split(':'));return 300-a*60-b
 except:return None
windows={}
for t in [30,60,90,120,150]:
 rs=[r for r in x['rows'] if elapsed(r) is not None and abs(elapsed(r)-t)<=1]
 r=min(rs,key=lambda r:abs(elapsed(r)-t)) if rs else None
 windows[str(t)]={'hudSeconds':elapsed(r),'size':r['hud'],'seq':r['r65Seq']} if r else None
changes=[{'seq':r['r65Seq'],'time':elapsed(r),'size':r['hud'],'dir':r['planOutput']['name'],'prior':r['planOutput'].get('r77',{}).get('priorName'),'suppressed':r['planOutput'].get('r77',{}).get('changedVsA',False),'retained':r['planOutput'].get('r72',{}).get('changed',False),'imageAvailable':any(f['seq']==r['r65Seq'] for f in x['decisionRing']['frames'])} for r in x['rows'] if r['planOutput'].get('r72',{}).get('changed') or r['planOutput'].get('r77',{}).get('changedVsA')]
for f in x['images']:f.pop('png',None)
for f in x['decisionRing']['frames']:f.pop('png',None)
x['rawSha256']=sha;(p/(g+'-results-noimages.json')).write_text(json.dumps(x,indent=2)+'\n')
s={'group':g,'outcome':x['outcome'],'seconds':x['seconds'],'terminalSize':x['stop']['size'],'reason':x['reason'],'windowSizes':windows,'accepted':len(x['rows']),'rejected':len(x['rejected']),'keysAfter':x['keysAfter'],'missed':x['missed'],'changes':changes,'ring':x['decisionRing']['stats'],'roundtripAll':all(f['pngRoundtripEqual'] for f in x['decisionRing']['frames']),'rawSha256':sha};(p/(g+'-summary.json')).write_text(json.dumps(s,indent=2)+'\n');print(json.dumps({k:v for k,v in s.items() if k!='changes'},indent=2))
