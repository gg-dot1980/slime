from pathlib import Path
import argparse,shutil
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();src=Path(__file__).resolve().parent;a.output.mkdir(parents=True,exist_ok=True)
for name,dst in [('game.html','r71.html'),('record.js','r71-record.js'),('frame.js','r71-frame.js'),('ring.js','r65-ring.js')]:shutil.copy(src/name,a.output/dst)
(a.output/'r71-v2.20').mkdir(exist_ok=True);game=(src/'game-source.html').read_text();(a.output/'r71-v2.20/index.html').write_text(game.replace('<script>','<script src="/r71-frame.js"></script><script>',1))
