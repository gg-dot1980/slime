import math
rate=-math.log(.65)/.1
# Frozen prefix scenarios, not measured bounds; continuous-equivalent inertia and unchanged radius.
def advance(v,goal,dt):
 e=math.exp(-rate*dt);return goal*dt+(v-goal)*(1-e)/rate,goal+(v-goal)*e
names=['東','東南','南','西南','西','西北','北','東北']
def path(p,name,delay,step=.1):
 a=names.index(name)*math.pi/4;d=[math.cos(a),math.sin(a)];old=[p['heading']['x'],p['heading']['y']];pos=[0,0];v=[p['velocity']['x'],p['velocity']['y']];wall=1e6;gap=1e6
 times=sorted(set([0,delay]+[round(i*step,9) for i in range(1,round(2/step)+1)]));last=0
 for t in times[1:]:
  goal=old if last<delay-1e-9 else d
  for j in range(2):
   delta,v[j]=advance(v[j],goal[j]*p['speed'],t-last);pos[j]+=delta
  for j,w in enumerate(p['map'].get('visibleWalls',[]) if p.get('map') else []):
   if w!=None:wall=min(wall,w+[pos[0],-pos[0],pos[1],-pos[1]][j]-p['hud'])
  if t<=1.1000001:
   for o in p['objects']:
    if not o['npc'] or not o['clipped'] and not o['isRed'] and o['r']<p['hud']*.98:continue
    body=o['dangerRadius'] if o['clipped'] else max(o['r'],p['hud']*1.1) if o['isRed'] else o['r'];gap=min(gap,math.hypot(o['x']+o['vx']*t-pos[0],o['y']+o['vy']*t-pos[1])-.75*(p['hud']+body)-12)
  last=t
 return {'wall':wall,'npcGap':gap}
