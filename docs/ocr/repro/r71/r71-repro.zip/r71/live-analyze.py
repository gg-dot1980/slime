import json,sys,hashlib,statistics,base64
from pathlib import Path
p=Path('r71');raw=Path(sys.argv[1]);x=json.loads(raw.read_text());events=x['timing']['events'];frames=[e for e in events if e['kind']=='frame'];keys=[e for e in events if e['kind']=='dispatch'];gaps=[b['rafTimestamp']-a['rafTimestamp'] for a,b in zip(frames,frames[1:])];offset=[]
for r in x['rows']:
 kk=[e for e in keys if r['capture']['end']<=e['before']<=r['recordAt']]
 if kk:offset.append(max(e['after'] for e in kk)-r['capture']['end'])
def stats(a):return {'n':len(a),'median':statistics.median(a) if a else None,'max':max(a) if a else None}
blocked=sum(not any(r['capture']['end']<f['callbackStart']<r['recordAt'] for f in frames) for r in x['rows']);nextFrame=[]
for r in x['rows']:
 k=[e['after'] for e in keys if r['capture']['end']<=e['before']<=r['recordAt']]
 if k:
  ff=[f['callbackStart'] for f in frames if f['callbackStart']>=max(k)]
  if ff:nextFrame.append(min(ff)-max(k))
ring=x['decisionRing'];summary={'reason':x['reason'],'outcome':x['outcome'],'elapsedWall':x['elapsedWall'],'hudStop':x['stop'],'decisionsWithNoGameCallbackDuringCompute':blocked,'dispatchToNextCallbackMs':stats(nextFrame),'accepted':len(x['rows']),'rejected':len(x['rejected']),'frameCallbacks':len(frames),'dispatchEvents':len(keys),'droppedEvents':x['timing']['dropped'],'rafGapMs':stats(gaps),'rafGapsAbove40ms':sum(v>40 for v in gaps),'callbackDurationMs':stats([e['callbackEnd']-e['callbackStart'] for e in frames]),'dispatchDurationMs':stats([e['after']-e['before'] for e in keys]),'captureToDispatchCompletionMs':stats(offset),'retainedFrames':len(ring['frames']),'distinctRetainedHashes':len({f['rawHash'] for f in ring['frames']}),'roundtripAll':all(f['pngRoundtripEqual'] for f in ring['frames']),'keysAfter':x['keysAfter'],'missingImages':x['missed'],'rawSha256':x.get('rawSha256') or hashlib.sha256(raw.read_bytes()).hexdigest()}
for f in ring['frames']:f.pop('png',None)
for im in x['images']:
 if 'png' in im:im['pngSha256']=hashlib.sha256(base64.b64decode(im.pop('png').split(',')[1])).hexdigest()
x['rawSha256']=summary['rawSha256'];(p/'live-results-noimages.json').write_text(json.dumps(x));(p/'live-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
