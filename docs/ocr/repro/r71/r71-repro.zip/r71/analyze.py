import json
from pathlib import Path
from model import path
rows=[]
for r in json.load(open('r71/inputs.json')):
 p=r['input'];checks=[]
 for delay in [0,.1,.2]:
  a=path(p,r['baseline'],delay);b=path(p,r['candidate'],delay);checks.append({'delay':delay,'baseline':a,'candidate':b,'pass':b['npcGap']>=a['npcGap']-1e-8 and b['wall']>=0})
 accept=all(x['pass'] for x in checks);validation=[]
 for delay in [.025,.05,.075,.125,.15,.175,.3]:
  a=path(p,r['baseline'],delay,.025);b=path(p,r['candidate'] if accept else r['baseline'],delay,.025);validation.append({'delay':delay,'baseline':a,'candidate':b,'npcLoss':b['npcGap']-a['npcGap'],'newNegative':a['npcGap']>=0 and b['npcGap']<0,'negativeWall':b['wall']<0})
 rows.append({'group':r['group'],'index':r['index'],'accept':accept,'checks':checks,'validation':validation})
groups={}
for g in sorted({r['group'] for r in rows}):
 rr=[r for r in rows if r['group']==g];vv=[v for r in rr if r['accept'] for v in r['validation'] if v['delay']<.3];stress=[v for r in rr if r['accept'] for v in r['validation'] if v['delay']==.3];groups[g]={'proposals':len(rr),'accepted':sum(r['accept'] for r in rr),'rejected':[r['index'] for r in rr if not r['accept']],'fineValidationPairs':len(vv),'npcLossPairs':sum(v['npcLoss']<-1e-8 for v in vv),'newNegativePairs':sum(v['newNegative'] for v in vv),'negativeWallPairs':sum(v['negativeWall'] for v in vv),'worstLoss':min([v['npcLoss'] for v in vv],default=None),'stress300msLossPairs':sum(v['npcLoss']<-1e-8 for v in stress)}
Path('r71/results.json').write_text(json.dumps({'groups':groups,'rows':rows},indent=2));print(json.dumps(groups,indent=2))
