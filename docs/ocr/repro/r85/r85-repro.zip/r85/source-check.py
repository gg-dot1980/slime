from pathlib import Path
import json,hashlib,re
p=Path(__file__).parent;out=[]
for f in sorted((p/'main-source').glob('*.html')):
 s=f.read_text();assert "if(s.r>player.r*1.1)" in s and 'else if(s.r>=player.r*1.08)' in s
 old=p.parent/'r83/rules'/f.name
 out.append({'version':re.search(r'SLIME ARENA · (v2\.\d+)',s).group(1),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'samePriorPinnedSource':f.read_bytes()==old.read_bytes(),'sourceCommit':'15f077ff9b96bf98b45860ca6ad0cbfe9e7a30e9','dangerLabel':'NPC>player*1.10','deathOnContact':'NPC>=player*1.08','thresholdCounterexamples':[{'npcPlayerRatio':r,'label':r>1.10,'canKillOnContact':r>=1.08} for r in [1.079,1.08,1.09,1.10,1.101]],'deployment':'not verified;web tool cannot access https://slime.gameson.cc/'} )
result={'versions':out,'localV220SameMain':(p/'main-source/game-v2.20.html').read_bytes()==(p.parent/'r80/game-source.html').read_bytes()};(p/'source-results.json').write_text(json.dumps(result,indent=2));print(result)
