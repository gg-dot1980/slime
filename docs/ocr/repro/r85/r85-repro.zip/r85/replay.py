from pathlib import Path
import json
p=Path(__file__).parent;x=json.load(open(p/'results.json'));known=[r for r in x['rows'] if r['part']];assert len(known)==45
for r in known:assert (r['hits']>=3)==r['prediction']==r['object']['isRed']
assert sum(r['visibleDangerText'] and r['prediction'] is False for r in known)==21
assert sum(not r['visibleDangerText'] and r['prediction'] is True for r in known)==0
assert all(r['object']['npc'] and (r['object']['clipped'] or r['object']['r']>=60*.98) for r in known if r['visibleDangerText'])
print('45numericdetectorchecks;21visiblemisses;0/24falsepositives;21/21stillthreatsbysize/clipping')
