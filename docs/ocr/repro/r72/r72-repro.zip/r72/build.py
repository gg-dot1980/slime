from pathlib import Path
import json
p=Path('r72');s=Path('r72/Current.js').read_text();body=s[s.index('function plan('):s.index('\nlet lastVision')]
body=body.replace('projectedR=r;const picked','projectedR=r,minWall=Infinity;const picked').replace('if(t<=1.1)for','for(let j=0;j<4;j++){const w=map?.visibleWalls?.[j];if(w!=null)minWall=Math.min(minWall,w+[x,-x,y,-y][j]-projectedR);} if(t<=1.1)for').replace('return {...d,target,clearance','return {...d,minWall,target,clearance')
needle='return {...pool[0],escaping:'
code="""let chosen=pool[0];const base=chosen;if(map?.visibleWalls?.some(w=>w!=null)){for(const q of pool)if(q.minWall>=20/3&&q.clearance>=base.clearance&&q.gain>=base.gain&&Math.min(q.minWall-20/3,q.clearance)>=Math.min(base.minWall-20/3,base.clearance)&&q.clearance>chosen.clearance)chosen=q;}if(chosen!==base){const p={objects,hud:r,map,speed,velocity:v,heading:old};if(![0,.1,.2].every(t=>{const a=prefixMetric(p,base,t),b=prefixMetric(p,chosen,t);return b.gap>=a.gap-1e-8&&b.wall>=0}))chosen=base;}return {...chosen,r72:{changed:chosen!==base,baseline:base.name},escaping:"""
assert needle in body;body=body.replace(needle,code);(p/'candidate-plan.js').write_text((p/'prefix.js').read_text()+body)
shell=Path('r72/baseline-shell.html').read_text();orig=shell[shell.index('function plan('):shell.index('\nlet lastVision')]
for group in ['A','B']:
 game=shell.replace('r71-record.js',f'r72-{group}-record.js');
 if group=='B':game=game.replace(orig,(p/'candidate-plan.js').read_text())
 (p/f'{group}.html').write_text(game)
 rec=Path('r72/baseline-record.js').read_text().replace('>20000','>210000').replace('diagnostic-20s-cap','wall-cap').replace('r71-timing-baseline-test043',f'r72-{group}-fixed-desktop-v2.20');(p/f'{group}-record.js').write_text(rec)
