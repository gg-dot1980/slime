import json,math
from pathlib import Path
P=Path('r72');x=json.load(open('r72/timing-source.json'));props=json.load(open('r72/timing-proposals.json'));gates={(r['group'],r['index']):r['accept'] for r in json.load(open('r72/r71-expected.json'))['rows']};frames=[e for e in x['timing']['events'] if e['kind']=='frame'];dispatch=[e for e in x['timing']['events'] if e['kind']=='dispatch'];schedules=[];lastEnd=-1
for row in x['rows']:
 start=row['capture']['end']
 if start<lastEnd or start+2000>frames[-1]['callbackStart']:continue
 keys=[e for e in dispatch if start<=e['before']<=row['recordAt']]
 if not keys:continue
 steps=[]
 for j,f in enumerate(frames):
  if j and start<f['callbackStart']<=start+2000:steps.append({'wall':(f['callbackStart']-start)/1000,'dt':min(.04,max(0,(f['rafTimestamp']-frames[j-1]['rafTimestamp'])/1000))})
 schedules.append({'start':start,'switch':(max(e['after'] for e in keys)-start)/1000,'steps':steps,'simulatedSeconds':sum(e['dt'] for e in steps)});lastEnd=start+2000
names=['東','東南','南','西南','西','西北','北','東北']
def path(p,name,schedule,npcClock):
 a=names.index(name)*math.pi/4;d=[math.cos(a),math.sin(a)];pos=[0.,0.];vel=[p['velocity']['x'],p['velocity']['y']];wall=1e6;gap=1e6;sim=0
 for f in schedule['steps']:
  dt=f['dt'];sim+=dt;direction=[p['heading']['x'],p['heading']['y']] if f['wall']<schedule['switch'] else d
  for k in range(2):vel[k]+=(direction[k]*p['speed']-vel[k])*min(1,dt*4.2);pos[k]+=vel[k]*dt
  for k,w in enumerate((p.get('map') or {}).get('visibleWalls') or []):
   if w!=None:wall=min(wall,w+[pos[0],-pos[0],pos[1],-pos[1]][k]-p['hud'])
  if f['wall']<=1.1:
   t=f['wall'] if npcClock=='wall' else sim
   for o in p['objects']:
    if not o['npc'] or not o['clipped'] and not o['isRed'] and o['r']<p['hud']*.98:continue
    body=o['dangerRadius'] if o['clipped'] else max(o['r'],p['hud']*1.1) if o['isRed'] else o['r'];gap=min(gap,math.hypot(o['x']+o['vx']*t-pos[0],o['y']+o['vy']*t-pos[1])-.75*(p['hud']+body)-12)
 return {'wall':wall,'gap':gap}
rows=[]
for r in props:
 if not r['group'].startswith('holdout-'):continue
 for i,s in enumerate(schedules):
  for clock in ['wall','simulation']:
   a=path(r['input'],r['baseline'],s,clock);b=path(r['input'],r['candidate'],s,clock);rows.append({'group':r['group'],'index':r['index'],'acceptedR71':gates[(r['group'],r['index'])],'schedule':i,'npcClock':clock,'baseline':a,'candidate':b,'loss':b['gap']-a['gap']})
summary={}
for accepted in [True,False]:
 for clock in ['wall','simulation']:
  rr=[r for r in rows if r['acceptedR71']==accepted and r['npcClock']==clock];summary[str(accepted)+'-'+clock]={'comparisons':len(rr),'losses':sum(r['loss']<-1e-8 for r in rr),'newNegative':sum(r['baseline']['gap']>=0 and r['candidate']['gap']<0 for r in rr),'wallNegative':sum(r['candidate']['wall']<0 for r in rr),'worstLoss':min([r['loss'] for r in rr],default=None),'lossCases':sorted({r['group']+':'+str(r['index']) for r in rr if r['loss']<-1e-8})}
(P/'results.json').write_text(json.dumps({'summary':summary,'schedules':schedules,'rows':rows},indent=2));print(json.dumps({'summary':summary,'scheduleCount':len(schedules),'simulatedSeconds':[s['simulatedSeconds'] for s in schedules]},indent=2))
