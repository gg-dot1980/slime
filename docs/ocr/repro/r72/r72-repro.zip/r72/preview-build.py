from pathlib import Path
import argparse,shutil
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();s=Path(__file__).resolve().parent;a.output.mkdir(parents=True,exist_ok=True)
for g in ['A','B']:
 shutil.copy(s/(g+'.html'),a.output/('r72-'+g+'.html'));shutil.copy(s/(g+'-record.js'),a.output/('r72-'+g+'-record.js'))
for f,t in [('ring.js','r65-ring.js'),('frame.js','r71-frame.js')]:shutil.copy(s/f,a.output/t)
(a.output/'r71-v2.20').mkdir(exist_ok=True);(a.output/'r71-v2.20/index.html').write_text((s/'game-source.html').read_text().replace('<script>','<script src="/r71-frame.js"></script><script>',1))
